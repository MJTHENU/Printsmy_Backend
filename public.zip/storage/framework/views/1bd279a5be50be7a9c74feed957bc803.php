<!DOCTYPE html>
<html>
<head>
    <title>Test Mail from Laravel</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
</body>
</html>
<?php /**PATH /home/rljjbe0ydf31/public_html/Printsmy_Backend/resources/views/emails/testMail.blade.php ENDPATH**/ ?>