<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h1>This is a test email.</h1>
</body>
</html>
<?php /**PATH /home/rljjbe0ydf31/public_html/Printsmy_Backend/resources/views/emails/test.blade.php ENDPATH**/ ?>